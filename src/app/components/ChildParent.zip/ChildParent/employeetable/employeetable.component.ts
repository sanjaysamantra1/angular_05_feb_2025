import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employeetable',
  templateUrl: './employeetable.component.html',
  styleUrls: ['./employeetable.component.css'],
  inputs:['employees']
})
export class EmployeeTableComponent {
  // @Input() employees: any[] = [];
  // @Output() employeeDeleted = new EventEmitter<number>();

  // deleteEmployee(eId: number) {
  //   this.employeeDeleted.emit(eId);
  // }
  employees:any;

  deleteEmployee(index: number) {
    this.employees.splice(index, 1);
      
  }
}
